from flask import Flask, flash, render_template, request, url_for,redirect
from transformers import pipeline 
import pandas as pd
from transformers import BertTokenizer, BertForSequenceClassification, Trainer, TrainingArguments
from datasets import Dataset, DatasetDict
import os
from werkzeug.utils import secure_filename  
from langchain.document_loaders import PyPDFLoader
from langchain.text_splitter import RecursiveCharacterTextSplitter
import json


UPLOAD_FOLDER = 'uploads'
ALLOWED_EXTENTIONS =  {'pdf'}

app = Flask(__name__)
app.config['UPLOAD_FOLDER']=UPLOAD_FOLDER
app.config['TEMPLATES_AUTO_RELOAD'] = True


def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENTIONS
# Load pre-trained NLP model (replace with actual model file path)
model = BertForSequenceClassification.from_pretrained('ClauseIdentifier\ClauseIdentifier')
tokenizer = BertTokenizer.from_pretrained('ClauseIdentifier\ClauseIdentifier')
nlp = pipeline('text-classification',model=model, tokenizer = tokenizer)
# Clause dictionary
clause_dict = {
    'Document Name': 0,
    'Parties': 1,
    'Agreement Date': 2,
    'Effective Date': 3,
    'Expiration Date': 4,
    'Renewal Term': 5,
    'Notice Period To Terminate Renewal': 6,
    'Governing Law': 7,
    'Most Favored Nation': 8,
    'Competitive Restriction Exception': 9,
    'Non-Compete': 10,
    'Exclusivity': 11,
    'No-Solicit Of Customers': 12,
    'No-Solicit Of Employees': 13,
    'Non-Disparagement': 14,
    'Termination For Convenience': 15,
    'Rofr/Rofo/Rofn': 16,
    'Change Of Control': 17,
    'Anti-Assignment': 18,
    'Revenue/Profit Sharing': 19,
    'Price Restrictions': 20,
    'Minimum Commitment': 21,
    'Volume Restriction': 22,
    'Ip Ownership Assignment': 23,
    'Joint Ip Ownership': 24,
    'License Grant': 25,
    'Non-Transferable License': 26,
    'Affiliate License-Licensor': 27,
    'Affiliate License-Licensee': 28,
    'Unlimited/All-You-Can-Eat-License': 29,
    'Irrevocable Or Perpetual License': 30,
    'Source Code Escrow': 31,
    'Post-Termination Services': 32,
    'Audit Rights': 33,
    'Uncapped Liability': 34,
    'Cap On Liability': 35,
    'Liquidated Damages': 36,
    'Warranty Duration': 37,
    'Insurance': 38,
    'Covenant Not To Sue': 39,
    'Third Party Beneficiary': 40
}



# Function to get clause name by number
def get_clause_name_by_number(number):
    # Reverse the dictionary (keys become values, values become keys)
    reverse_clause_dict = {v: k for k, v in clause_dict.items()}
    
    # Return the clause name for the given number
    return reverse_clause_dict.get(number, "Clause number not found")

# Home route to render the input form
@app.route('/')
def index():
    return render_template('index.html')

# Prediction route to handle form submission and return model result
@app.route('/predict', methods=['POST'])
def predict():
    if request.method == 'POST':
        # Get form data (text input from user)
        input_text = request.form['input_text']
        
        # Preprocess input_text if needed (e.g., tokenization, vectorization)
        # Assuming the model expects raw text or some preprocessing method is applied
        prediction = nlp([input_text])  # Wrap in list if the model expects an array-like structure
        label = prediction[0]['label']
        score = prediction[0]['score']
        
        number_part = label.split('_')[1]
        print('number passed to fun:',number_part)
        result = get_clause_name_by_number(int(number_part))
        finalresult = "'"+result+"'" + ", Confidence Score:" + str(score)
        # Show prediction on the UI
        result_dict = {
                    "clause_name": result,
                    "confidence_score": score
                }
        fresult = []
        fresult.append(result_dict)
        return render_template('index.html', prediction_text=fresult)

@app.route('/Upload', methods=['POST'])
def Upload():
    if request.method == 'POST':
        # check if the post request has the file part
        if 'file' not in request.files:
            flash('No file part')
            return redirect(request.url)
        file = request.files['file']
        # If the user does not select a file, the browser submits an
        # empty file without a filename.
        if file.filename == '':
            flash('No selected file')
            return redirect(request.url)
        if file and allowed_file(file.filename):
            filename = secure_filename(file.filename)
            file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
            #return redirect(url_for('download_file', name=filename))
            print("file uploaded successfully")
            loader = PyPDFLoader(os.path.join(app.config['UPLOAD_FOLDER'], filename))
            documents = loader.load()
            text_splitter = RecursiveCharacterTextSplitter( chunk_size = 1000, chunk_overlap=50, separators=["\n\n","\n"," ","."])
            chunked_text= text_splitter.split_documents(documents)
            s=''
            results_list = []
            results_list2 = []
            for idx, chunk in enumerate(chunked_text):
                print(f"{idx+1} -----------------------Para-----------------------:\n {chunk.page_content}\n{'-'*40}")
                size = len(chunk.page_content.split())
                print(size)
                if size <=200:
                    prediction = nlp([chunk.page_content])  # Wrap in list if the model expects an array-like structure
                    label = prediction[0]['label']
                    score = prediction[0]['score']
                    number_part = label.split('_')[1]
                    print('number passed to fun:',number_part)
                    result = get_clause_name_by_number(int(number_part))
                    finalresult = "'"+result+"'" + ", Confidence Score:" + str(score)
                    print(finalresult)
                    #s = s +chunk.page_content+ finalresult+"\n "
                    s = s+ finalresult+"\n "
                    # Create a dictionary for each chunk's result and confidence score
                    result_dict = {
                        "clause_name": result,
                        "confidence_score": score
                    }
                    
                    # Append the dictionary to the results list
                    results_list.append(result_dict)
                    resultjson = json.dumps(results_list)
                #list_keys = list(resultjson.keys())
                print("Results as JSON:\n", resultjson)
    #            print(list_keys)


    return render_template('index.html',prediction_text=results_list)

if __name__ == '__main__':
    app.run(debug=True)
