from transformers import pipeline 
import pandas as pd
from transformers import BertTokenizer, BertForSequenceClassification, Trainer, TrainingArguments
from datasets import Dataset, DatasetDict

model = BertForSequenceClassification.from_pretrained('ClauseIdentifier\ClauseIdentifier')
tokenizer = BertTokenizer.from_pretrained('ClauseIdentifier\ClauseIdentifier')

## create a pipeline for classification 
nlp = pipeline('text-classification',model=model, tokenizer = tokenizer)
result =nlp("This contract has been signed between euro oil corp ltd and gas company ltd")